package login;

import java.sql.*;
import javax.swing.*;
public class sqliteConnectionClass {
	
	Connection conn = null;
	
	public static Connection dbConnector() {
		try {
			Class.forName("org.sqlite.JDBC");
			Connection conn = DriverManager.getConnection("jdbc:sqlite:C:\\Users\\urooj\\uni stuff\\EmployeeDatabase.db.db");
			return conn;
		}
		catch(Exception e){
			
			JOptionPane.showMessageDialog(null, e);
			return null;
		}
	}
	public static Connection codesConnector() {
		try {
			Class.forName("org.sqlite.JDBC");
			Connection conn = DriverManager.getConnection("jdbc:sqlite:C:\\Users\\urooj\\uni stuff\\uniqueCodes.db");
			return conn;
		}
		catch(Exception e) {
			JOptionPane.showMessageDialog(null, e);
			return null; 
		}
	}
}
