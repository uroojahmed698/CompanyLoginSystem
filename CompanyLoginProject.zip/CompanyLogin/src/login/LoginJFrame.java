package login;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JSpinner;
import javax.swing.JSeparator;

public class LoginJFrame extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField userInput;
	private JPasswordField passwordInput;
	private JTextField registeringCodeInput;
	private JTextField positionInput;
	private JTextField userRegInput;
	private JTextField lastNameInput;
	private JTextField firstnameInput;
	private JTextField passwordRegInput;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginJFrame frame = new LoginJFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LoginJFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 864, 579);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 128, 192));
		contentPane.setForeground(new Color(0, 0, 0));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel Title = new JLabel("UROOJ's MOCK COMPANY");
		Title.setFont(new Font("Georgia", Font.PLAIN, 25));
		Title.setBounds(256, 11, 337, 37);
		contentPane.add(Title);
		
		JLabel loginTitle = new JLabel("STAFF LOGIN");
		loginTitle.setFont(new Font("Tahoma", Font.BOLD, 14));
		loginTitle.setBounds(374, 91, 102, 14);
		contentPane.add(loginTitle);
		
		JLabel user = new JLabel("Username:");
		user.setFont(new Font("Tahoma", Font.BOLD, 11));
		user.setBounds(210, 129, 70, 14);
		contentPane.add(user);
		
		JLabel password = new JLabel("Password:");
		password.setFont(new Font("Tahoma", Font.BOLD, 11));
		password.setBounds(210, 171, 70, 14);
		contentPane.add(password);
		
		userInput = new JTextField();
		userInput.setBounds(311, 126, 228, 20);
		contentPane.add(userInput);
		userInput.setColumns(10);
		
		passwordInput = new JPasswordField();
		passwordInput.setBounds(311, 168, 228, 20);
		contentPane.add(passwordInput);
		passwordInput.setColumns(10);
		
		JButton enterButton = new JButton("Login");
		
		enterButton.addActionListener(new ActionListener() {

		    public void actionPerformed(ActionEvent e) {

		        String username = userInput.getText();
		        String password = passwordInput.getText();

		        boolean successful = Authorizor.login(username, password);

		        if(successful) {
		        	 WelcomePage welcome = new WelcomePage(username);
		        	 welcome.setVisible(true);
		             LoginJFrame.this.dispose();
		        } 
		        else {
		            JOptionPane.showMessageDialog(null, "Invalid username or password.");
		        }
		    }
		});
		enterButton.setBounds(321, 205, 102, 22);
		contentPane.add(enterButton);
		
		JLabel registerVar = new JLabel("OR REGISTER");
		registerVar.setFont(new Font("Tahoma", Font.BOLD, 14));
		registerVar.setBounds(374, 254, 102, 22);
		contentPane.add(registerVar);
		
		registeringCodeInput = new JTextField();
		registeringCodeInput.setBounds(366, 306, 277, 20);
		contentPane.add(registeringCodeInput);
		registeringCodeInput.setColumns(10);
		
		JLabel registeringCode = new JLabel("Code given by hiring manager:");
		registeringCode.setFont(new Font("Tahoma", Font.BOLD, 11));
		registeringCode.setBounds(160, 309, 183, 14);
		contentPane.add(registeringCode);
		
		JLabel firstNameVar = new JLabel("First Name:");
		firstNameVar.setFont(new Font("Tahoma", Font.BOLD, 11));
		firstNameVar.setBounds(66, 402, 81, 14);
		contentPane.add(firstNameVar);
		
		JLabel lastNameVar = new JLabel("Last Name:");
		lastNameVar.setFont(new Font("Tahoma", Font.BOLD, 11));
		lastNameVar.setBounds(66, 449, 81, 14);
		contentPane.add(lastNameVar);
		
		JLabel positionVar = new JLabel("Position (Team member, Manager, Supervisor): ");
		positionVar.setFont(new Font("Tahoma", Font.BOLD, 11));
		positionVar.setBounds(66, 354, 277, 14);
		contentPane.add(positionVar);
		
		JLabel registeredUser = new JLabel("Username:");
		registeredUser.setFont(new Font("Tahoma", Font.BOLD, 11));
		registeredUser.setBounds(432, 402, 70, 14);
		contentPane.add(registeredUser);
		
		JLabel registeredPassword = new JLabel("Password: ");
		registeredPassword.setFont(new Font("Tahoma", Font.BOLD, 11));
		registeredPassword.setBounds(432, 449, 70, 14);
		contentPane.add(registeredPassword);
		
		positionInput = new JTextField();
		positionInput.setColumns(10);
		positionInput.setBounds(366, 351, 277, 20);
		contentPane.add(positionInput);
		
		userRegInput = new JTextField();
		userRegInput.setColumns(10);
		userRegInput.setBounds(548, 399, 183, 20);
		contentPane.add(userRegInput);
		
		lastNameInput = new JTextField();
		lastNameInput.setColumns(10);
		lastNameInput.setBounds(191, 446, 183, 20);
		contentPane.add(lastNameInput);
		
		firstnameInput = new JTextField();
		firstnameInput.setColumns(10);
		firstnameInput.setBounds(191, 399, 183, 20);
		contentPane.add(firstnameInput);
		
		passwordRegInput = new JPasswordField();
		passwordRegInput.setColumns(10);
		passwordRegInput.setBounds(548, 446, 183, 20);
		contentPane.add(passwordRegInput);
		
		JButton signupButt = new JButton("Sign Up");
		signupButt.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String code = registeringCodeInput.getText();
				String firstName = firstnameInput.getText();
				String lastName = lastNameInput.getText();
				String username = userRegInput.getText();
				String password = passwordRegInput.getText();
				String role = positionInput.getText();
				
				boolean valid = Register.signUp(username, password, firstName, lastName, role, code);
				if(valid) {
					WelcomePage welcome = new WelcomePage(username);
		        	welcome.setVisible(true);
		            LoginJFrame.this.dispose();
				}
				
				

			}
		});
		signupButt.setBounds(289, 488, 102, 22);
		contentPane.add(signupButt);
		
		JButton clearButt = new JButton("Clear");
		clearButt.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				registeringCodeInput.setText(null);
				firstnameInput.setText(null);
				lastNameInput.setText(null);
				userRegInput.setText(null);
				passwordRegInput.setText(null);
				positionInput.setText(null);
			}
		});
		clearButt.setBounds(447, 488, 102, 22);
		contentPane.add(clearButt);
		
		JButton clearButt2 = new JButton("Clear");
		clearButt2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				userInput.setText(null);
				passwordInput.setText(null);
			}
		});
		clearButt2.setBounds(437, 205, 102, 22);
		contentPane.add(clearButt2);

	}
}
