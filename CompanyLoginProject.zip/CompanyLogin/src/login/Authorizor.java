package login;

import java.sql.Connection; 
import java.sql.PreparedStatement; 
import java.sql.ResultSet;

public class Authorizor {
	public static boolean login(String username, String password) {
		String sql = "SELECT * FROM employees WHERE username = ? AND password_hash = ?";
		
		try(Connection conn = sqliteConnectionClass.dbConnector();
				PreparedStatement stmt = conn.prepareStatement(sql)){
				stmt.setString(1, username);
				stmt.setString(2,  password);
				
				ResultSet rs = stmt.executeQuery();
				
				if(rs.next()) {
					
					return true;
				}
		
	}
	catch(Exception e) {
		e.printStackTrace();
	}
	return false;
	
}
}
