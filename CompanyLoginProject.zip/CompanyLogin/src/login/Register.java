package login;
import java.sql.Connection; 
import java.sql.PreparedStatement; 
import java.sql.ResultSet;
import javax.swing.JOptionPane;

public class Register {
	public static boolean signUp(String username, String password, String firstName, String lastName, String role, String code) {
		  Connection employeeConn = null;
	      Connection codeConn = null;
	      
	      try {
	    	  String codeSQL = "SELECT used FROM registeringCodes WHERE code = ?";

	    	  employeeConn = sqliteConnectionClass.dbConnector();
	    	  codeConn = sqliteConnectionClass.codesConnector();
	    	  
	    	  PreparedStatement codeStatement = codeConn.prepareStatement(codeSQL);
	    	  
	    	  codeStatement.setString(1, code);
	    	  
	    	  ResultSet codeResult = codeStatement.executeQuery();
	    	  
	    	  if(!codeResult.next()){
	                JOptionPane.showMessageDialog(null, "Invalid registration code.");
	                return false;
	          }
	    	  boolean used = codeResult.getBoolean("used");
	    	  
	    	  if(used) {
	    		  JOptionPane.showMessageDialog(null, "Code already used");
	    		  return false;
	    	  }
	    	  
	    	  String userSQL = "SELECT username FROM employees WHERE username = ?";
	    	  PreparedStatement userStatement = employeeConn.prepareStatement(userSQL);
	    	  
	    	  userStatement.setString(1, username);
	    	  ResultSet userResult = userStatement.executeQuery();
	    	  
	    	  if(userResult.next()) {
	    		  JOptionPane.showMessageDialog(null, "Username already in use");
	    		  return false;
	    	  }
	    	  
	    	  String insertSQL = "INSERT INTO employees " + "(username, password_hash, first_name, last_name, role) " + "VALUES (?, ?, ?, ?, ?)";
	    	  PreparedStatement insertStatement = employeeConn.prepareStatement(insertSQL);
	    	  
	    	  insertStatement.setString(1, username);
	    	  insertStatement.setString(2, password);
	    	  insertStatement.setString(3, firstName);
	    	  insertStatement.setString(4, lastName);
	    	  insertStatement.setString(5, role);
	    	  
	    	  insertStatement.executeUpdate();
	    	  
	    	  String updateSQL = "UPDATE registeringCodes SET used = 1 WHERE code = ?";
	    	  PreparedStatement updateStatement = codeConn.prepareStatement(updateSQL);
	    	 
	    	  updateStatement.setString(1, code);
	    	  updateStatement.executeUpdate();

	          JOptionPane.showMessageDialog(null, "Registered successfully!");

	          return true;
	      }
	      catch(Exception e){
	    	  JOptionPane.showMessageDialog(null, e.getMessage());
	    	  return false;
	      }
	      finally {
	    	  try {
	    		  if(employeeConn != null) {
	    			  employeeConn.close();
	    		  }
	    		  if(codeConn != null) {
	    			  codeConn.close();
	    		  }
	    	  }
	    	  catch(Exception e) {
	    		  e.printStackTrace();
	    	  }
	      }
	}
	
	
}
