package login;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.Color;

public class WelcomePage extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					WelcomePage frame = new WelcomePage(null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public WelcomePage(String username) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(128, 128, 192));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel welcomeSign = new JLabel("WELCOME!");
		welcomeSign.setBounds(124, 10, 187, 37);
		welcomeSign.setForeground(new Color(255, 255, 255));
		welcomeSign.setFont(new Font("Snap ITC", Font.PLAIN, 28));
		welcomeSign.setHorizontalAlignment(SwingConstants.CENTER);
		contentPane.add(welcomeSign);
		
		JLabel welcomeInfo = new JLabel("Login Succesful! " + username);
		welcomeInfo.setFont(new Font("SimSun", Font.PLAIN, 15));
		welcomeInfo.setBounds(30, 78, 322, 14);
		contentPane.add(welcomeInfo);
		
		String sql = "SELECT first_name, last_name, role FROM employees WHERE username = ?";
		try(Connection c = sqliteConnectionClass.dbConnector();
				PreparedStatement stmt = c.prepareStatement(sql)){
			stmt.setString(1, username);
			ResultSet res = stmt.executeQuery();
			
			if(res.next()) {
				String firstName = res.getString("first_name");
				String lastName = res.getString("last_name");
				String role = res.getString("role");

				 JLabel nameLabel = new JLabel("Name: " + firstName + " " + lastName);
		         nameLabel.setBounds(30, 110, 300, 20);
		         contentPane.add(nameLabel);

		         JLabel roleLabel = new JLabel("Role: " + role);
		         roleLabel.setBounds(30, 140, 300, 20);
	             contentPane.add(roleLabel);
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		

	}
}
